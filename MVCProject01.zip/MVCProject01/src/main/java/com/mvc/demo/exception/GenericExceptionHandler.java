package com.mvc.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GenericExceptionHandler {
	@ExceptionHandler(NoUserIdFoundException.class)
	public ResponseEntity<String> NoUserIdFoundExceptionHandler (NoUserIdFoundException ex){
		String strMsg = ex.getMessage();
		return new ResponseEntity<>(strMsg, HttpStatus.NOT_FOUND);
	}
}
