package com.mvc.demo.entity;

public class loginForm {
	
	String UID;
	String PWD;
	
	public loginForm() {}

	public loginForm(String uID, String pWD) {
		super();
		UID = uID;
		PWD = pWD;
	}

	public String getUID() {
		return UID;
	}

	public void setUID(String uID) {
		UID = uID;
	}

	public String getPWD() {
		return PWD;
	}

	public void setPWD(String pWD) {
		PWD = pWD;
	}
	
	
}
