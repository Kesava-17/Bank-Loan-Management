package com.mvc.demo.exception;

public class NoUserIdFoundException extends Exception{
	public NoUserIdFoundException(String strMsg){
		super(strMsg);
	}

}
