package com.mvc.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.mvc.demo.entity.loginForm;
import com.mvc.demo.exception.NoUserIdFoundException;

@Controller
public class MyController {
	
	@GetMapping("/hello")
	public String hello() {
		String strFileName = "MVCFirst";
		
		return strFileName;
	}
	
	@GetMapping("/getUser/{Id}")
	public ResponseEntity<String> getUser(@PathVariable Integer Id) throws NoUserIdFoundException{
		if(Id == 1) {
			String strName = "Kesava";
			return new ResponseEntity<>(strName, HttpStatus.OK);
		}else
			throw new NoUserIdFoundException ("No User Found for this id..");
	}
	
	@GetMapping("/login")
	public String login(Model model) {
		model.addAttribute("loginform" , new loginForm());
		return "login";
	}
	
	@PostMapping("/login")
	public String login(Model model, @ModelAttribute("loginform") loginForm loginform) {
		if(loginform.getUID().equals("Kesava") && loginform.getPWD().equals("Admin")) {
			return "loginSuccess";
		}else {
			model.addAttribute("loginform", new loginForm());
			return "loginFail";
		}
		
	}
	
}
