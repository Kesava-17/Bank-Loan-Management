
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>



<style>
	
</style>


<form:form class = "lform" method = "post" action="login" modelAttribute= "loginform">
	<h1> Login Form </h1>
	User Id: <br/>
	<form:input path="UID" /><br/><br/>
	Password:<br/>
	<form:input path="PWD"/> <br/> <br/>
	
	<button type="submit">Login</button>
	
</form:form>