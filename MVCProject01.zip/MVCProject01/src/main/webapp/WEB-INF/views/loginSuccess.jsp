

<h1> User Id : ${loginform.getUID()}</h1>
<h1> Your Vaild User. Please Continue...</h1> 