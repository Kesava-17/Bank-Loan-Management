<HTML>
	<STYLE>
		h1{
			background-color:red;
			color : white;
			text-align :center;
			margin-top : 100px;
		}
		
		
	</STYLE>
	<BODY>
		<h1>This is First MVC Web App</h1>
	</BODY>
</HTML>